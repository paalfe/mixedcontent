/* $Id: rem.c,v 1.2 2004/02/01 13:52:17 skaus Exp $
 *  REM -- includes comments "remarks" into batch scripts
 */

#include "../config.h"

#include "../include/command.h"

#pragma argsused
int cmd_rem(char *param)
{
  return 0;
}
